
import time
import cx_Oracle
start = time.time()
con = cx_Oracle.connect("<uid>", "<pwd>", "<ipaddr>/<sid>")
# pls provide respective values for uid, pwd before executing this pgm
print ("Connected to ", con.version)
cur = con.cursor()
#cur.arraysize = 100
cur.arraysize = 2000
cur.execute('select * from bigtab')
res = cur.fetchall()
# print res  # uncomment to display the query results
elapsed = (time.time() - start)
print (elapsed, " seconds")
cur.close()
con.close()
print ("Disconnected from Oracle")
